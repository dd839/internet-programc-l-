import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function DELETE(request, { params }) {
  try {
    // Check if user is authenticated and is admin
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    if (session.user.role !== 'admin') {
      return NextResponse.json(
        { error: 'Bu işlem için yetkiniz yok' },
        { status: 403 }
      );
    }
    
    const { categoryId } = params;
    
    if (!categoryId) {
      return NextResponse.json(
        { error: 'Kategori ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Check if category exists
    const category = await prisma.category.findUnique({
      where: { id: categoryId },
      include: {
        news: true,
      },
    });
    
    if (!category) {
      return NextResponse.json(
        { error: 'Kategori bulunamadı' },
        { status: 404 }
      );
    }
    
    // Check if category has news
    if (category.news.length > 0) {
      return NextResponse.json(
        { error: 'Bu kategoriye ait haberler bulunmaktadır. Önce haberleri silmelisiniz.' },
        { status: 400 }
      );
    }
    
    // Delete category
    await prisma.category.delete({
      where: { id: categoryId }
    });
    
    return NextResponse.json(
      { message: 'Kategori başarıyla silindi' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Delete category error:', error);
    return NextResponse.json(
      { error: 'Kategori silinirken bir hata oluştu' },
      { status: 500 }
    );
  }
} 