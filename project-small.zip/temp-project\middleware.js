import { NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';

export async function middleware(request) {
  const path = request.nextUrl.pathname;
  
  // Define public paths that don't require authentication
  const publicPaths = ['/', '/login', '/register'];
  const isPublicPath = publicPaths.includes(path) || 
                      path.startsWith('/news/') || 
                      path.startsWith('/api/auth/');
  
  // Define admin-only paths
  const adminPaths = ['/admin', '/admin/users', '/admin/categories', '/admin/news'];
  const isAdminPath = adminPaths.some(adminPath => path.startsWith(adminPath));
  
  // Get the session token
  const token = await getToken({ 
    req: request,
    secret: process.env.NEXTAUTH_SECRET
  });
  
  // Check if the user is authenticated
  const isAuthenticated = !!token;
  
  // Check if the user is an admin
  const isAdmin = token?.role === 'admin';
  
  // Redirect logic based on authentication and authorization
  
  // If the path is public and user is not authenticated, allow access
  if (isPublicPath && !isAuthenticated) {
    return NextResponse.next();
  }
  
  // If the path is admin-only and user is not an admin, redirect to home
  if (isAdminPath && !isAdmin) {
    return NextResponse.redirect(new URL('/', request.url));
  }
  
  // If the path requires authentication and user is not authenticated, redirect to login
  if (!isPublicPath && !isAuthenticated) {
    return NextResponse.redirect(new URL('/login', request.url));
  }
  
  // Allow access for authenticated users to non-admin paths or admin users to admin paths
  return NextResponse.next();
}

// Configure which paths the middleware should run on
export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|public).*)',
  ],
}; 