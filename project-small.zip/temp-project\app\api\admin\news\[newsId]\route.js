import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Get a single news item
export async function GET(request, { params }) {
  try {
    // Check if user is authenticated
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    const { newsId } = params;
    
    if (!newsId) {
      return NextResponse.json(
        { error: 'Haber ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Get news
    const news = await prisma.news.findUnique({
      where: { id: newsId },
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
        category: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    
    if (!news) {
      return NextResponse.json(
        { error: 'Haber bulunamadı' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ news }, { status: 200 });
  } catch (error) {
    console.error('Get news error:', error);
    return NextResponse.json(
      { error: 'Haber alınırken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// Update a news item
export async function PUT(request, { params }) {
  try {
    // Check if user is authenticated
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    const { newsId } = params;
    
    if (!newsId) {
      return NextResponse.json(
        { error: 'Haber ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Get request body
    const body = await request.json();
    const { title, content, categoryId, image, published } = body;
    
    if (!title || !content || !categoryId) {
      return NextResponse.json(
        { error: 'Başlık, içerik ve kategori gereklidir' },
        { status: 400 }
      );
    }
    
    // Check if news exists
    const existingNews = await prisma.news.findUnique({
      where: { id: newsId },
    });
    
    if (!existingNews) {
      return NextResponse.json(
        { error: 'Haber bulunamadı' },
        { status: 404 }
      );
    }
    
    // Check if user is admin or the author
    if (session.user.role !== 'admin' && existingNews.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Bu haberi düzenleme yetkiniz yok' },
        { status: 403 }
      );
    }
    
    // Check if category exists
    const category = await prisma.category.findUnique({
      where: { id: categoryId },
    });
    
    if (!category) {
      return NextResponse.json(
        { error: 'Kategori bulunamadı' },
        { status: 404 }
      );
    }
    
    // Update news
    const updatedNews = await prisma.news.update({
      where: { id: newsId },
      data: {
        title,
        content,
        categoryId,
        image,
        published: published !== undefined ? published : existingNews.published,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
        category: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    
    return NextResponse.json(
      { news: updatedNews, message: 'Haber başarıyla güncellendi' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Update news error:', error);
    return NextResponse.json(
      { error: 'Haber güncellenirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// Delete a news item
export async function DELETE(request, { params }) {
  try {
    // Check if user is authenticated
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    const { newsId } = params;
    
    if (!newsId) {
      return NextResponse.json(
        { error: 'Haber ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Check if news exists
    const existingNews = await prisma.news.findUnique({
      where: { id: newsId },
    });
    
    if (!existingNews) {
      return NextResponse.json(
        { error: 'Haber bulunamadı' },
        { status: 404 }
      );
    }
    
    // Check if user is admin or the author
    if (session.user.role !== 'admin' && existingNews.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Bu haberi silme yetkiniz yok' },
        { status: 403 }
      );
    }
    
    // Delete news
    await prisma.news.delete({
      where: { id: newsId },
    });
    
    return NextResponse.json(
      { message: 'Haber başarıyla silindi' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Delete news error:', error);
    return NextResponse.json(
      { error: 'Haber silinirken bir hata oluştu' },
      { status: 500 }
    );
  }
} 