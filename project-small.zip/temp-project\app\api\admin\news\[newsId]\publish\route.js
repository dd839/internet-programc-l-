import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Toggle publish status of a news item
export async function PUT(request, { params }) {
  try {
    // Check if user is authenticated
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    // Check if user is admin
    if (session.user.role !== 'admin') {
      return NextResponse.json(
        { error: 'Bu işlem için yetkiniz yok' },
        { status: 403 }
      );
    }
    
    const { newsId } = params;
    
    if (!newsId) {
      return NextResponse.json(
        { error: 'Haber ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Get request body
    const body = await request.json();
    const { published } = body;
    
    if (published === undefined) {
      return NextResponse.json(
        { error: 'Yayın durumu gereklidir' },
        { status: 400 }
      );
    }
    
    // Check if news exists
    const existingNews = await prisma.news.findUnique({
      where: { id: newsId },
    });
    
    if (!existingNews) {
      return NextResponse.json(
        { error: 'Haber bulunamadı' },
        { status: 404 }
      );
    }
    
    // Update news publish status
    const updatedNews = await prisma.news.update({
      where: { id: newsId },
      data: {
        published,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
        category: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    
    return NextResponse.json(
      { 
        news: updatedNews, 
        message: published 
          ? 'Haber başarıyla yayınlandı' 
          : 'Haber başarıyla taslak olarak kaydedildi' 
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Update news publish status error:', error);
    return NextResponse.json(
      { error: 'Haber yayın durumu güncellenirken bir hata oluştu' },
      { status: 500 }
    );
  }
} 