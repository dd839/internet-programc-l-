import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(request) {
  try {
    // Check if user is authenticated
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    // Get request body
    const body = await request.json();
    const { receiverId, content } = body;
    
    if (!receiverId || !content) {
      return NextResponse.json(
        { error: 'Alıcı ID ve mesaj içeriği gereklidir' },
        { status: 400 }
      );
    }
    
    // Check if receiver exists
    const receiver = await prisma.user.findUnique({
      where: { id: receiverId }
    });
    
    if (!receiver) {
      return NextResponse.json(
        { error: 'Alıcı kullanıcı bulunamadı' },
        { status: 404 }
      );
    }
    
    // Create message
    const message = await prisma.message.create({
      data: {
        content,
        senderId: session.user.id,
        receiverId,
      }
    });
    
    return NextResponse.json(
      { message, success: true },
      { status: 201 }
    );
  } catch (error) {
    console.error('Send message error:', error);
    return NextResponse.json(
      { error: 'Mesaj gönderilirken bir hata oluştu' },
      { status: 500 }
    );
  }
} 