'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function Messages() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [users, setUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [messageText, setMessageText] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (status === 'authenticated') {
      fetchUsers();
    }
  }, [status]);

  useEffect(() => {
    if (selectedUser) {
      fetchMessages(selectedUser.id);
    }
  }, [selectedUser]);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/users');
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Kullanıcılar yüklenirken bir hata oluştu.');
      }
      
      // Filter out the current user
      const filteredUsers = data.users.filter(user => user.id !== session.user.id);
      setUsers(filteredUsers);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (userId) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/messages/${userId}`);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Mesajlar yüklenirken bir hata oluştu.');
      }
      
      setMessages(data.messages);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    
    if (!messageText.trim() || !selectedUser) {
      return;
    }
    
    try {
      const response = await fetch('/api/messages/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          receiverId: selectedUser.id,
          content: messageText,
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Mesaj gönderilirken bir hata oluştu.');
      }
      
      // Add the new message to the list and clear the input
      setMessages([...messages, data.message]);
      setMessageText('');
    } catch (error) {
      setError(error.message);
    }
  };

  if (status === 'loading') {
    return <div className="text-center py-10">Yükleniyor...</div>;
  }

  if (status === 'unauthenticated') {
    router.push('/login');
    return null;
  }

  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Mesajlar</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-3">
          {/* Users list */}
          <div className="border-r border-gray-200">
            <div className="p-4 bg-gray-50 border-b border-gray-200">
              <h2 className="font-semibold">Kullanıcılar</h2>
            </div>
            <div className="overflow-y-auto h-[500px]">
              {users.length > 0 ? (
                <ul>
                  {users.map((user) => (
                    <li key={user.id}>
                      <button
                        onClick={() => setSelectedUser(user)}
                        className={`w-full text-left px-4 py-3 border-b border-gray-100 hover:bg-blue-50 transition-colors flex items-center ${
                          selectedUser?.id === user.id ? 'bg-blue-50' : ''
                        }`}
                      >
                        <div className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center mr-3">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                        </div>
                      </button>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="p-4 text-gray-500">Kullanıcı bulunamadı.</p>
              )}
            </div>
          </div>
          
          {/* Messages */}
          <div className="col-span-2 flex flex-col h-[500px]">
            {selectedUser ? (
              <>
                <div className="p-4 bg-gray-50 border-b border-gray-200">
                  <h2 className="font-semibold">{selectedUser.name}</h2>
                </div>
                
                <div className="flex-grow overflow-y-auto p-4 space-y-4">
                  {messages.length > 0 ? (
                    messages.map((message) => (
                      <div
                        key={message.id}
                        className={`max-w-[70%] p-3 rounded-lg ${
                          message.senderId === session.user.id
                            ? 'bg-blue-500 text-white ml-auto'
                            : 'bg-gray-100'
                        }`}
                      >
                        <p>{message.content}</p>
                        <p className={`text-xs mt-1 ${
                          message.senderId === session.user.id
                            ? 'text-blue-100'
                            : 'text-gray-500'
                        }`}>
                          {new Date(message.createdAt).toLocaleString('tr-TR')}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-gray-500 py-8">
                      Henüz mesaj yok. Bir mesaj göndererek sohbete başlayın.
                    </p>
                  )}
                </div>
                
                <div className="p-4 border-t border-gray-200">
                  <form onSubmit={sendMessage} className="flex">
                    <input
                      type="text"
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      className="flex-grow input mr-2"
                      placeholder="Mesajınızı yazın..."
                      required
                    />
                    <button type="submit" className="btn">
                      Gönder
                    </button>
                  </form>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center text-gray-500">
                  <p className="mb-2">Mesajlaşmak için bir kullanıcı seçin.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
} 