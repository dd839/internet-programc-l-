import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Get all news
export async function GET(request) {
  try {
    // Check if user is authenticated
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    // Get all news
    const news = await prisma.news.findMany({
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
        category: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
    
    return NextResponse.json({ news }, { status: 200 });
  } catch (error) {
    console.error('Get news error:', error);
    return NextResponse.json(
      { error: 'Haberler alınırken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// Create a new news
export async function POST(request) {
  try {
    // Check if user is authenticated
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    // Get request body
    const body = await request.json();
    const { title, content, categoryId, image, published = false } = body;
    
    if (!title || !content || !categoryId) {
      return NextResponse.json(
        { error: 'Başlık, içerik ve kategori gereklidir' },
        { status: 400 }
      );
    }
    
    // Check if category exists
    const category = await prisma.category.findUnique({
      where: { id: categoryId },
    });
    
    if (!category) {
      return NextResponse.json(
        { error: 'Kategori bulunamadı' },
        { status: 404 }
      );
    }
    
    // Create news
    const news = await prisma.news.create({
      data: {
        title,
        content,
        image,
        published,
        authorId: session.user.id,
        categoryId,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
        category: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    
    return NextResponse.json(
      { news, message: 'Haber başarıyla oluşturuldu' },
      { status: 201 }
    );
  } catch (error) {
    console.error('Create news error:', error);
    return NextResponse.json(
      { error: 'Haber oluşturulurken bir hata oluştu' },
      { status: 500 }
    );
  }
} 