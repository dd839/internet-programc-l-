'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';

export default function NewsPage() {
  const searchParams = useSearchParams();
  const categoryId = searchParams.get('category');
  
  const [news, setNews] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchCategories();
    fetchNews();
  }, [categoryId]);

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories');
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Kategoriler yüklenirken bir hata oluştu.');
      }
      
      setCategories(data.categories);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchNews = async () => {
    try {
      setLoading(true);
      
      let url = '/api/news';
      if (categoryId) {
        url += `?categoryId=${categoryId}`;
      }
      
      const response = await fetch(url);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Haberler yüklenirken bir hata oluştu.');
      }
      
      setNews(data.news);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Haberler</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar with categories */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-xl font-bold mb-4">Kategoriler</h2>
            <ul className="space-y-2">
              <li>
                <Link 
                  href="/news" 
                  className={`block px-3 py-2 rounded ${!categoryId ? 'bg-blue-100 text-blue-800' : 'hover:bg-gray-100'}`}
                >
                  Tüm Haberler
                </Link>
              </li>
              {categories.map((category) => (
                <li key={category.id}>
                  <Link 
                    href={`/news?category=${category.id}`} 
                    className={`block px-3 py-2 rounded ${categoryId === category.id ? 'bg-blue-100 text-blue-800' : 'hover:bg-gray-100'}`}
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* News list */}
        <div className="lg:col-span-3">
          {loading ? (
            <div className="text-center py-10">Yükleniyor...</div>
          ) : news.length > 0 ? (
            <div className="space-y-6">
              {news.map((item) => (
                <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="md:flex">
                    {item.image && (
                      <div className="md:flex-shrink-0">
                        <img 
                          src={item.image} 
                          alt={item.title} 
                          className="h-48 w-full object-cover md:w-48"
                        />
                      </div>
                    )}
                    <div className="p-6">
                      <div className="flex items-center">
                        <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full uppercase font-semibold tracking-wide">
                          {item.category.name}
                        </span>
                        <span className="mx-2 text-gray-500 text-sm">
                          {formatDate(item.createdAt)}
                        </span>
                      </div>
                      <Link 
                        href={`/news/${item.id}`} 
                        className="block mt-2 text-xl font-semibold text-gray-900 hover:text-blue-600"
                      >
                        {item.title}
                      </Link>
                      <p className="mt-3 text-gray-600 line-clamp-3">
                        {item.content.substring(0, 150)}...
                      </p>
                      <div className="mt-4 flex items-center">
                        <div className="flex-shrink-0">
                          <span className="text-sm font-medium text-gray-900">
                            {item.author.name}
                          </span>
                        </div>
                      </div>
                      <Link 
                        href={`/news/${item.id}`} 
                        className="mt-4 inline-flex items-center text-blue-600 hover:underline"
                      >
                        Devamını Oku
                        <svg className="ml-1 w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <p className="text-gray-500">Bu kategoride haber bulunamadı.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
} 