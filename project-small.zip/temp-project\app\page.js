'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';

export default function Home() {
  const { data: session } = useSession();
  const [latestNews, setLatestNews] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch latest news
        const newsResponse = await fetch('/api/news?limit=6');
        const newsData = await newsResponse.json();
        
        if (!newsResponse.ok) {
          throw new Error(newsData.error || 'Haberler yüklenirken bir hata oluştu.');
        }
        
        setLatestNews(newsData.news);
        
        // Fetch categories
        const categoriesResponse = await fetch('/api/categories');
        const categoriesData = await categoriesResponse.json();
        
        if (!categoriesResponse.ok) {
          throw new Error(categoriesData.error || 'Kategoriler yüklenirken bir hata oluştu.');
        }
        
        setCategories(categoriesData.categories);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
  };

  return (
    <div className="container mx-auto py-8 px-4">
      {/* Hero section */}
      <section className="bg-blue-600 text-white rounded-lg shadow-xl p-8 mb-12">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Haber Portalına Hoş Geldiniz</h1>
          <p className="text-xl mb-6">
            En güncel haberler, analizler ve daha fazlası için doğru adrestesiniz.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/news" className="btn bg-white text-blue-600 hover:bg-gray-100">
              Haberlere Göz At
            </Link>
            {!session && (
              <Link href="/register" className="btn bg-transparent border border-white hover:bg-blue-700">
                Üye Ol
              </Link>
            )}
          </div>
        </div>
      </section>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-8">
          {error}
        </div>
      )}
      
      {/* Latest news section */}
      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold">Son Haberler</h2>
          <Link href="/news" className="text-blue-600 hover:underline">
            Tüm Haberleri Gör
          </Link>
        </div>
        
        {loading ? (
          <div className="text-center py-10">Yükleniyor...</div>
        ) : latestNews.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestNews.map((news) => (
              <div key={news.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                {news.image && (
                  <img 
                    src={news.image} 
                    alt={news.title} 
                    className="w-full h-48 object-cover"
                  />
                )}
                <div className="p-6">
                  <div className="flex items-center mb-2">
                    <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full uppercase font-semibold tracking-wide">
                      {news.category.name}
                    </span>
                    <span className="mx-2 text-gray-500 text-sm">
                      {formatDate(news.createdAt)}
                    </span>
                  </div>
                  <Link 
                    href={`/news/${news.id}`} 
                    className="block text-xl font-semibold text-gray-900 hover:text-blue-600 mb-2"
                  >
                    {news.title}
                  </Link>
                  <p className="text-gray-600 mb-4 line-clamp-2">
                    {news.content.substring(0, 120)}...
                  </p>
                  <Link 
                    href={`/news/${news.id}`} 
                    className="text-blue-600 hover:underline inline-flex items-center"
                  >
                    Devamını Oku
                    <svg className="ml-1 w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <p className="text-gray-500">Henüz haber bulunmamaktadır.</p>
          </div>
        )}
      </section>
      
      {/* Categories section */}
      <section className="mb-12">
        <h2 className="text-3xl font-bold mb-6">Kategoriler</h2>
        
        {loading ? (
          <div className="text-center py-10">Yükleniyor...</div>
        ) : categories.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categories.map((category) => (
              <Link 
                key={category.id}
                href={`/news?category=${category.id}`}
                className="bg-white rounded-lg shadow-md p-6 text-center hover:bg-blue-50 transition-colors"
              >
                <h3 className="text-lg font-semibold">{category.name}</h3>
              </Link>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <p className="text-gray-500">Henüz kategori bulunmamaktadır.</p>
          </div>
        )}
      </section>
      
      {/* CTA section */}
      {!session && (
        <section className="bg-gray-100 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Haber Portalımıza Katılın</h2>
          <p className="text-lg text-gray-600 mb-6">
            Üye olarak haberlere yorum yapabilir ve daha fazla özellikten yararlanabilirsiniz.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/register" className="btn">
              Hemen Üye Ol
            </Link>
            <Link href="/login" className="btn bg-gray-500 hover:bg-gray-600">
              Giriş Yap
            </Link>
          </div>
        </section>
      )}
    </div>
  );
} 