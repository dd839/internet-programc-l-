'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function CreateNews() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [categories, setCategories] = useState([]);
  const [newsData, setNewsData] = useState({
    title: '',
    content: '',
    categoryId: '',
    image: '',
    published: false,
  });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (status === 'authenticated') {
      if (session.user.role !== 'admin') {
        router.push('/');
      } else {
        fetchCategories();
      }
    } else if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, session, router]);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/categories');
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Kategoriler yüklenirken bir hata oluştu.');
      }
      
      setCategories(data.categories);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNewsData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setSubmitting(true);
      setError('');
      
      if (!newsData.title.trim() || !newsData.content.trim() || !newsData.categoryId) {
        setError('Başlık, içerik ve kategori alanları zorunludur.');
        setSubmitting(false);
        return;
      }
      
      const response = await fetch('/api/admin/news', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newsData),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Haber oluşturulurken bir hata oluştu.');
      }
      
      // Redirect to news list
      router.push('/admin/news');
    } catch (error) {
      setError(error.message);
      setSubmitting(false);
    }
  };

  if (status === 'loading' || loading) {
    return <div className="text-center py-10">Yükleniyor...</div>;
  }

  if (status === 'authenticated' && session.user.role !== 'admin') {
    return null; // Middleware will redirect
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Yeni Haber Ekle</h1>
        <Link href="/admin/news" className="btn bg-gray-500 hover:bg-gray-600">
          Haberlere Dön
        </Link>
      </div>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="title" className="block text-gray-700 font-medium mb-2">
              Başlık
            </label>
            <input
              type="text"
              id="title"
              name="title"
              value={newsData.title}
              onChange={handleInputChange}
              className="input"
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="categoryId" className="block text-gray-700 font-medium mb-2">
              Kategori
            </label>
            <select
              id="categoryId"
              name="categoryId"
              value={newsData.categoryId}
              onChange={handleInputChange}
              className="input"
              required
            >
              <option value="">Kategori Seçin</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          
          <div className="mb-4">
            <label htmlFor="image" className="block text-gray-700 font-medium mb-2">
              Görsel URL (opsiyonel)
            </label>
            <input
              type="text"
              id="image"
              name="image"
              value={newsData.image}
              onChange={handleInputChange}
              className="input"
              placeholder="https://example.com/image.jpg"
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="content" className="block text-gray-700 font-medium mb-2">
              İçerik
            </label>
            <textarea
              id="content"
              name="content"
              value={newsData.content}
              onChange={handleInputChange}
              className="input"
              rows="10"
              required
            />
          </div>
          
          <div className="mb-6">
            <label className="flex items-center">
              <input
                type="checkbox"
                name="published"
                checked={newsData.published}
                onChange={handleInputChange}
                className="mr-2"
              />
              <span className="text-gray-700">Hemen Yayınla</span>
            </label>
          </div>
          
          <div className="flex justify-end">
            <button
              type="submit"
              className="btn"
              disabled={submitting}
            >
              {submitting ? 'Oluşturuluyor...' : 'Haberi Oluştur'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
} 