'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function AdminCategories() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [categories, setCategories] = useState([]);
  const [newCategory, setNewCategory] = useState({ name: '', description: '' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (status === 'authenticated') {
      if (session.user.role !== 'admin') {
        router.push('/');
      } else {
        fetchCategories();
      }
    } else if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, session, router]);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/categories');
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Kategoriler yüklenirken bir hata oluştu.');
      }
      
      setCategories(data.categories);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewCategory(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCreateCategory = async (e) => {
    e.preventDefault();
    
    try {
      if (!newCategory.name.trim()) {
        setError('Kategori adı gereklidir.');
        return;
      }
      
      const response = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newCategory),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Kategori oluşturulurken bir hata oluştu.');
      }
      
      // Add the new category to the list
      setCategories([data.category, ...categories]);
      
      // Reset the form
      setNewCategory({ name: '', description: '' });
      
      setSuccessMessage('Kategori başarıyla oluşturuldu.');
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } catch (error) {
      setError(error.message);
    }
  };

  const handleDeleteCategory = async (categoryId) => {
    try {
      if (!window.confirm('Bu kategoriyi silmek istediğinizden emin misiniz?')) {
        return;
      }
      
      const response = await fetch(`/api/admin/categories/${categoryId}`, {
        method: 'DELETE',
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Kategori silinirken bir hata oluştu.');
      }
      
      // Remove category from the list
      setCategories(categories.filter(category => category.id !== categoryId));
      
      setSuccessMessage('Kategori başarıyla silindi.');
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } catch (error) {
      setError(error.message);
    }
  };

  if (status === 'loading' || loading) {
    return <div className="text-center py-10">Yükleniyor...</div>;
  }

  if (status === 'authenticated' && session.user.role !== 'admin') {
    return null; // Middleware will redirect
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Kategori Yönetimi</h1>
        <Link href="/admin" className="btn bg-gray-500 hover:bg-gray-600">
          Admin Paneline Dön
        </Link>
      </div>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {successMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {successMessage}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Create category form */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-4">Yeni Kategori Ekle</h2>
            <form onSubmit={handleCreateCategory}>
              <div className="mb-4">
                <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                  Kategori Adı
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={newCategory.name}
                  onChange={handleInputChange}
                  className="input"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="description" className="block text-gray-700 font-medium mb-2">
                  Açıklama
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={newCategory.description}
                  onChange={handleInputChange}
                  className="input"
                  rows="3"
                />
              </div>
              
              <button type="submit" className="btn w-full">
                Kategori Ekle
              </button>
            </form>
          </div>
        </div>
        
        {/* Categories list */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 bg-gray-50 border-b border-gray-200">
              <h2 className="font-semibold">Kategoriler</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="py-3 px-4 text-left">Kategori Adı</th>
                    <th className="py-3 px-4 text-left">Açıklama</th>
                    <th className="py-3 px-4 text-left">Oluşturulma Tarihi</th>
                    <th className="py-3 px-4 text-left">İşlemler</th>
                  </tr>
                </thead>
                <tbody>
                  {categories.length > 0 ? (
                    categories.map((category) => (
                      <tr key={category.id} className="border-t">
                        <td className="py-3 px-4 font-medium">{category.name}</td>
                        <td className="py-3 px-4">
                          {category.description || <span className="text-gray-400">Açıklama yok</span>}
                        </td>
                        <td className="py-3 px-4">
                          {new Date(category.createdAt).toLocaleDateString('tr-TR')}
                        </td>
                        <td className="py-3 px-4">
                          <button
                            onClick={() => handleDeleteCategory(category.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            Sil
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr className="border-t">
                      <td colSpan="4" className="py-3 px-4 text-center text-gray-500">
                        Henüz kategori bulunmamaktadır.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 