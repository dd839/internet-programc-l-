import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Get a single news item
export async function GET(request, { params }) {
  try {
    const { newsId } = params;
    
    if (!newsId) {
      return NextResponse.json(
        { error: 'Haber ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Get news
    const news = await prisma.news.findUnique({
      where: { 
        id: newsId,
        published: true, // Only return published news
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
        category: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    
    if (!news) {
      return NextResponse.json(
        { error: 'Haber bulunamadı' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ news }, { status: 200 });
  } catch (error) {
    console.error('Get news error:', error);
    return NextResponse.json(
      { error: 'Haber alınırken bir hata oluştu' },
      { status: 500 }
    );
  }
} 