import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(request) {
  try {
    // Check if user is authenticated and is admin
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    if (session.user.role !== 'admin') {
      return NextResponse.json(
        { error: 'Bu işlem için yetkiniz yok' },
        { status: 403 }
      );
    }
    
    // Get statistics
    const [
      totalUsers,
      totalNews,
      publishedNews,
      totalCategories,
      totalComments,
      totalMessages
    ] = await Promise.all([
      prisma.user.count(),
      prisma.news.count(),
      prisma.news.count({
        where: { published: true }
      }),
      prisma.category.count(),
      prisma.comment.count(),
      prisma.message.count()
    ]);
    
    const stats = {
      totalUsers,
      totalNews,
      publishedNews,
      totalCategories,
      totalComments,
      totalMessages
    };
    
    return NextResponse.json({ stats }, { status: 200 });
  } catch (error) {
    console.error('Get admin stats error:', error);
    return NextResponse.json(
      { error: 'İstatistikler alınırken bir hata oluştu' },
      { status: 500 }
    );
  }
} 