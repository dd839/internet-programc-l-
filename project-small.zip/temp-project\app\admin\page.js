'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function AdminDashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (status === 'authenticated') {
      if (session.user.role !== 'admin') {
        router.push('/');
      } else {
        fetchStats();
      }
    } else if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, session, router]);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/stats');
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'İstatistikler yüklenirken bir hata oluştu.');
      }
      
      setStats(data.stats);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (status === 'loading' || loading) {
    return <div className="text-center py-10">Yükleniyor...</div>;
  }

  if (status === 'authenticated' && session.user.role !== 'admin') {
    return null; // Middleware will redirect
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Admin Paneli</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-700">Toplam Kullanıcı</h2>
            <p className="text-3xl font-bold">{stats.totalUsers}</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-700">Toplam Haber</h2>
            <p className="text-3xl font-bold">{stats.totalNews}</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-700">Yayında Olan Haber</h2>
            <p className="text-3xl font-bold">{stats.publishedNews}</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-700">Toplam Kategori</h2>
            <p className="text-3xl font-bold">{stats.totalCategories}</p>
          </div>
        </div>
      )}
      
      {/* Admin actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-bold mb-4">Kullanıcı Yönetimi</h2>
            <p className="text-gray-600 mb-4">
              Kullanıcıları görüntüleyin, düzenleyin ve yönetin.
            </p>
            <Link href="/admin/users" className="btn w-full">
              Kullanıcıları Yönet
            </Link>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-bold mb-4">Haber Yönetimi</h2>
            <p className="text-gray-600 mb-4">
              Haberleri oluşturun, düzenleyin ve yayınlayın.
            </p>
            <Link href="/admin/news" className="btn w-full">
              Haberleri Yönet
            </Link>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-bold mb-4">Kategori Yönetimi</h2>
            <p className="text-gray-600 mb-4">
              Haber kategorilerini oluşturun ve yönetin.
            </p>
            <Link href="/admin/categories" className="btn w-full">
              Kategorileri Yönet
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
} 