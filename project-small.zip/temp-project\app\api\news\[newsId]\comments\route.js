import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Get comments for a news item
export async function GET(request, { params }) {
  try {
    const { newsId } = params;
    
    if (!newsId) {
      return NextResponse.json(
        { error: 'Haber ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Get comments
    const comments = await prisma.comment.findMany({
      where: { newsId },
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
    
    return NextResponse.json({ comments }, { status: 200 });
  } catch (error) {
    console.error('Get comments error:', error);
    return NextResponse.json(
      { error: 'Yorumlar alınırken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// Create a new comment
export async function POST(request, { params }) {
  try {
    // Check if user is authenticated
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    const { newsId } = params;
    
    if (!newsId) {
      return NextResponse.json(
        { error: 'Haber ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Check if news exists and is published
    const news = await prisma.news.findUnique({
      where: { 
        id: newsId,
        published: true,
      },
    });
    
    if (!news) {
      return NextResponse.json(
        { error: 'Haber bulunamadı' },
        { status: 404 }
      );
    }
    
    // Get request body
    const body = await request.json();
    const { content } = body;
    
    if (!content || !content.trim()) {
      return NextResponse.json(
        { error: 'Yorum içeriği gereklidir' },
        { status: 400 }
      );
    }
    
    // Create comment
    const comment = await prisma.comment.create({
      data: {
        content,
        authorId: session.user.id,
        newsId,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    
    return NextResponse.json(
      { comment, message: 'Yorum başarıyla oluşturuldu' },
      { status: 201 }
    );
  } catch (error) {
    console.error('Create comment error:', error);
    return NextResponse.json(
      { error: 'Yorum oluşturulurken bir hata oluştu' },
      { status: 500 }
    );
  }
} 