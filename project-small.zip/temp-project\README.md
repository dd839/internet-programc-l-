# Next.js Projesi

Bu proje [Next.js](https://nextjs.org/) ile oluşturulmuş bir web uygulamasıdır.

## Başlangıç

İlk olarak, geliştirme sunucusunu çalıştırın:

```bash
npm run dev
# veya
yarn dev
# veya
pnpm dev
# veya
bun dev
```

Tarayıcınızda [http://localhost:3000](http://localhost:3000) adresini açarak sonucu görüntüleyin.

## Proje Yapısı

- `app/` - App Router ile sayfa ve bileşenler
- `public/` - Statik dosyalar (resimler, fontlar vb.)
- `app/page.js` - Ana sayfa
- `app/layout.js` - Kök düzen bileşeni

## Daha Fazla Bilgi

Next.js hakkında daha fazla bilgi edinmek için aşağıdaki kaynakları inceleyebilirsiniz:

- [Next.js Dokümantasyonu](https://nextjs.org/docs) - Next.js özellikleri ve API hakkında bilgi edinin.
- [Next.js Öğrenin](https://nextjs.org/learn) - İnteraktif Next.js öğreticisi.

## Dağıtım

Next.js uygulamanızı dağıtmanın en kolay yolu [Vercel Platformu](https://vercel.com/new) kullanmaktır.

Daha fazla ayrıntı için [Next.js dağıtım dokümantasyonunu](https://nextjs.org/docs/deployment) kontrol edin. 