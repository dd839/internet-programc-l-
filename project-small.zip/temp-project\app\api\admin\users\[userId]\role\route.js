import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function PUT(request, { params }) {
  try {
    // Check if user is authenticated and is admin
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }
    
    if (session.user.role !== 'admin') {
      return NextResponse.json(
        { error: 'Bu işlem için yetkiniz yok' },
        { status: 403 }
      );
    }
    
    const { userId } = params;
    
    if (!userId) {
      return NextResponse.json(
        { error: 'Kullanıcı ID gereklidir' },
        { status: 400 }
      );
    }
    
    // Don't allow changing own role
    if (userId === session.user.id) {
      return NextResponse.json(
        { error: 'Kendi rolünüzü değiştiremezsiniz' },
        { status: 400 }
      );
    }
    
    // Get request body
    const body = await request.json();
    const { role } = body;
    
    if (!role || (role !== 'user' && role !== 'admin')) {
      return NextResponse.json(
        { error: 'Geçerli bir rol belirtilmelidir (user veya admin)' },
        { status: 400 }
      );
    }
    
    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { id: userId }
    });
    
    if (!user) {
      return NextResponse.json(
        { error: 'Kullanıcı bulunamadı' },
        { status: 404 }
      );
    }
    
    // Update user role
    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: { role }
    });
    
    return NextResponse.json({
      message: 'Kullanıcı rolü başarıyla güncellendi',
      user: {
        id: updatedUser.id,
        name: updatedUser.name,
        email: updatedUser.email,
        role: updatedUser.role
      }
    }, { status: 200 });
  } catch (error) {
    console.error('Admin update user role error:', error);
    return NextResponse.json(
      { error: 'Kullanıcı rolü güncellenirken bir hata oluştu' },
      { status: 500 }
    );
  }
} 