'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function AdminNews() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (status === 'authenticated') {
      if (session.user.role !== 'admin') {
        router.push('/');
      } else {
        fetchNews();
      }
    } else if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, session, router]);

  const fetchNews = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/news');
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Haberler yüklenirken bir hata oluştu.');
      }
      
      setNews(data.news);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTogglePublish = async (newsId, currentStatus) => {
    try {
      const response = await fetch(`/api/admin/news/${newsId}/publish`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ published: !currentStatus }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Haber durumu güncellenirken bir hata oluştu.');
      }
      
      // Update news in the list
      setNews(news.map(item => 
        item.id === newsId ? { ...item, published: !currentStatus } : item
      ));
      
      setSuccessMessage(`Haber ${!currentStatus ? 'yayınlandı' : 'taslak olarak kaydedildi'}.`);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } catch (error) {
      setError(error.message);
    }
  };

  const handleDeleteNews = async (newsId) => {
    try {
      if (!window.confirm('Bu haberi silmek istediğinizden emin misiniz?')) {
        return;
      }
      
      const response = await fetch(`/api/admin/news/${newsId}`, {
        method: 'DELETE',
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Haber silinirken bir hata oluştu.');
      }
      
      // Remove news from the list
      setNews(news.filter(item => item.id !== newsId));
      
      setSuccessMessage('Haber başarıyla silindi.');
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } catch (error) {
      setError(error.message);
    }
  };

  if (status === 'loading' || loading) {
    return <div className="text-center py-10">Yükleniyor...</div>;
  }

  if (status === 'authenticated' && session.user.role !== 'admin') {
    return null; // Middleware will redirect
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Haber Yönetimi</h1>
        <div className="flex gap-2">
          <Link href="/admin/news/create" className="btn">
            Yeni Haber Ekle
          </Link>
          <Link href="/admin" className="btn bg-gray-500 hover:bg-gray-600">
            Admin Paneline Dön
          </Link>
        </div>
      </div>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {successMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {successMessage}
        </div>
      )}
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="py-3 px-4 text-left">Başlık</th>
                <th className="py-3 px-4 text-left">Kategori</th>
                <th className="py-3 px-4 text-left">Yazar</th>
                <th className="py-3 px-4 text-left">Durum</th>
                <th className="py-3 px-4 text-left">Tarih</th>
                <th className="py-3 px-4 text-left">İşlemler</th>
              </tr>
            </thead>
            <tbody>
              {news.length > 0 ? (
                news.map((item) => (
                  <tr key={item.id} className="border-t">
                    <td className="py-3 px-4 font-medium">{item.title}</td>
                    <td className="py-3 px-4">{item.category.name}</td>
                    <td className="py-3 px-4">{item.author.name}</td>
                    <td className="py-3 px-4">
                      <span 
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          item.published 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {item.published ? 'Yayında' : 'Taslak'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {new Date(item.createdAt).toLocaleDateString('tr-TR')}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex space-x-2">
                        <Link 
                          href={`/admin/news/${item.id}/edit`}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          Düzenle
                        </Link>
                        <button
                          onClick={() => handleTogglePublish(item.id, item.published)}
                          className={`${
                            item.published 
                              ? 'text-yellow-600 hover:text-yellow-800' 
                              : 'text-green-600 hover:text-green-800'
                          }`}
                        >
                          {item.published ? 'Taslağa Al' : 'Yayınla'}
                        </button>
                        <button
                          onClick={() => handleDeleteNews(item.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          Sil
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr className="border-t">
                  <td colSpan="6" className="py-3 px-4 text-center text-gray-500">
                    Henüz haber bulunmamaktadır.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
} 