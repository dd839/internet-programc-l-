import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Get all published news
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const categoryId = searchParams.get('categoryId');
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit')) : undefined;
    
    // Build query
    const query = {
      where: {
        published: true,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
          },
        },
        category: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    };
    
    // Add category filter if provided
    if (categoryId) {
      query.where.categoryId = categoryId;
    }
    
    // Add limit if provided
    if (limit && !isNaN(limit)) {
      query.take = limit;
    }
    
    // Get news
    const news = await prisma.news.findMany(query);
    
    return NextResponse.json({ news }, { status: 200 });
  } catch (error) {
    console.error('Get news error:', error);
    return NextResponse.json(
      { error: 'Haberler alınırken bir hata oluştu' },
      { status: 500 }
    );
  }
} 