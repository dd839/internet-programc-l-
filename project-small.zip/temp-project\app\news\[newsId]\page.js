'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function NewsDetail({ params }) {
  const { newsId } = params;
  const { data: session } = useSession();
  const router = useRouter();
  
  const [news, setNews] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [commentError, setCommentError] = useState('');

  useEffect(() => {
    fetchNewsDetail();
    fetchComments();
  }, [newsId]);

  const fetchNewsDetail = async () => {
    try {
      setLoading(true);
      
      const response = await fetch(`/api/news/${newsId}`);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Haber detayı yüklenirken bir hata oluştu.');
      }
      
      setNews(data.news);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchComments = async () => {
    try {
      const response = await fetch(`/api/news/${newsId}/comments`);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Yorumlar yüklenirken bir hata oluştu.');
      }
      
      setComments(data.comments);
    } catch (error) {
      console.error('Error fetching comments:', error);
    }
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    
    if (!session) {
      router.push('/login');
      return;
    }
    
    try {
      setSubmitting(true);
      setCommentError('');
      
      if (!comment.trim()) {
        setCommentError('Yorum alanı boş olamaz.');
        setSubmitting(false);
        return;
      }
      
      const response = await fetch(`/api/news/${newsId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content: comment }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Yorum gönderilirken bir hata oluştu.');
      }
      
      // Add the new comment to the list
      setComments([data.comment, ...comments]);
      
      // Clear the comment input
      setComment('');
    } catch (error) {
      setCommentError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
  };

  if (loading) {
    return <div className="text-center py-10">Yükleniyor...</div>;
  }

  if (error) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
        <div className="mt-4">
          <Link href="/news" className="text-blue-600 hover:underline">
            Haberlere Dön
          </Link>
        </div>
      </div>
    );
  }

  if (!news) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded">
          Haber bulunamadı.
        </div>
        <div className="mt-4">
          <Link href="/news" className="text-blue-600 hover:underline">
            Haberlere Dön
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-4">
        <Link href="/news" className="text-blue-600 hover:underline flex items-center">
          <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clipRule="evenodd" />
          </svg>
          Haberlere Dön
        </Link>
      </div>
      
      <article className="bg-white rounded-lg shadow-md overflow-hidden">
        {news.image && (
          <div className="relative">
            <img 
              src={news.image} 
              alt={news.title} 
              className="w-full h-64 sm:h-96 object-cover"
            />
          </div>
        )}
        
        <div className="p-6">
          <div className="flex items-center mb-4">
            <Link 
              href={`/news?category=${news.category.id}`}
              className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full uppercase font-semibold tracking-wide"
            >
              {news.category.name}
            </Link>
            <span className="mx-2 text-gray-500 text-sm">
              {formatDate(news.createdAt)}
            </span>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{news.title}</h1>
          
          <div className="flex items-center mb-6">
            <span className="text-sm font-medium text-gray-900">
              Yazar: {news.author.name}
            </span>
          </div>
          
          <div className="prose max-w-none">
            {news.content.split('\n').map((paragraph, index) => (
              <p key={index} className="mb-4">{paragraph}</p>
            ))}
          </div>
        </div>
      </article>
      
      {/* Comments section */}
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-6">Yorumlar</h2>
        
        {/* Comment form */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          {session ? (
            <form onSubmit={handleCommentSubmit}>
              <div className="mb-4">
                <label htmlFor="comment" className="block text-gray-700 font-medium mb-2">
                  Yorumunuz
                </label>
                <textarea
                  id="comment"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="input"
                  rows="4"
                  placeholder="Düşüncelerinizi paylaşın..."
                  required
                />
                {commentError && (
                  <p className="mt-1 text-red-600 text-sm">{commentError}</p>
                )}
              </div>
              
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="btn"
                  disabled={submitting}
                >
                  {submitting ? 'Gönderiliyor...' : 'Yorum Yap'}
                </button>
              </div>
            </form>
          ) : (
            <div className="text-center py-4">
              <p className="mb-2">Yorum yapmak için giriş yapmalısınız.</p>
              <Link href="/login" className="btn">
                Giriş Yap
              </Link>
            </div>
          )}
        </div>
        
        {/* Comments list */}
        <div className="space-y-4">
          {comments.length > 0 ? (
            comments.map((comment) => (
              <div key={comment.id} className="bg-white rounded-lg shadow-md p-4">
                <div className="flex justify-between mb-2">
                  <span className="font-medium">{comment.author.name}</span>
                  <span className="text-sm text-gray-500">{formatDate(comment.createdAt)}</span>
                </div>
                <p className="text-gray-700">{comment.content}</p>
              </div>
            ))
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <p className="text-gray-500">Henüz yorum yapılmamış. İlk yorumu siz yapın!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
} 